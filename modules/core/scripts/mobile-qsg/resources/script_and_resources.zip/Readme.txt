    IoTs 3.0.0 QSG Setup guide

1. Navigate to this folder using the terminal, Note that this (Readme.txt) flie should be located under <IoTS_HOME>/core/samples/mobile-qsg/ directory.
2. Stop the WSO2 IoTS if already runing
3. Then execute the copy-files.sh script
4. Start the WSO2 IoTS server
5. Once server is started execute the mobile-qsg.sh script
6. Then login to the https://<your-server>:9443/devicemgt/ and use the username,password as alex alex@IoTS, Note that for this sample we have configured above user from the script. If you want to run this script again you have to login as admin and remove the user alex, chris and role iotMobileUser from the IoT Server.



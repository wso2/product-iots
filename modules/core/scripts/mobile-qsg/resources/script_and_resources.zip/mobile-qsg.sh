#!/bin/bash
# product-iots qsg sample setup script

echo "Starting wso2iots-3.0.0 QSG setup ..."
java -jar "mobile-qsg.jar"
echo "wso2iots-3.0.0 QSG setup completed."
